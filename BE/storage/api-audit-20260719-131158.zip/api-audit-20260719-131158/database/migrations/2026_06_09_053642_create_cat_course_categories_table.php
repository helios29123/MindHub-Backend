<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('course_categories')) {
            return;
        }

        Schema::create('course_categories', function (Blueprint $table) {
            $table->foreignId('course_id')->constrained('courses')->cascadeOnDelete();
            $table->foreignId('category_id')->constrained('categories')->cascadeOnDelete();
            $table->timestamp('created_at')->nullable();

            $table->primary(['course_id', 'category_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('course_categories');
    }
};
